<div>
    <style>
        nav svg{
            height:20px;
        }
    nav .hidden{
        display:block;
    }
    .wishlisted{
        background: #F15412 !important;
        border: 1px solid transparent !important;
    }
    .wishlisted i{
        color: #fff !important;
    }
    </style>
        <main class="main">
            <div class="page-header breadcrumb-wrap">
                <div class="container">
                    <div class="breadcrumb">
                        <a href="/" rel="nofollow">Home</a>
                        <span></span> Exclusive Deals
                    </div>
                </div>
            </div>
            <section class="mt-50 mb-50">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="shop-product-fillter">
                                <div class="totall-product">
                                    <p> We found <strong class="text-brand"><?php echo e($products->total()); ?></strong> items for you!</p>
                                </div>
                               
                            </div>
    
                            <div class="row product-grid-3">
                                <?php
                                $witems = Cart::instance('wishlist')->content()->pluck('id');
                            ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4 col-md-4 col-6 col-sm-6">
                                        <div class="product-cart-wrap mb-30">
                                            <div class="product-img-action-wrap">
                                                <div class="product-img product-img-zoom">
                                                    <a href="<?php echo e(route('product.details', ['slug' => $product->slug])); ?>">
                                                        <img class="default-img" src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($product->images); ?>-1.jpg" alt="<?php echo e($product->name); ?>">
                                                        <img class="hover-img" src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($product->images); ?>-2.jpg" alt="<?php echo e($product->name); ?>">
                                                    </a>
                                                </div>
                                           
                                                <div class="product-badges product-badges-position product-badges-mrg">
                                                    <span class="hot" style="background:green">InStock</span>
                                                </div>
                                            </div>
                                            <div class="product-content-wrap">
                                              
                                                <h2>
                                                    <a
                                                        href="<?php echo e(route('product.details', ['slug' => $product->slug])); ?>"><?php echo e($product->name); ?></a>
                                                </h2>
                                                <div class="product-price">
                                                    <span><?php echo e($product->regular_price); ?>$ </span>
                                                    <span class="old-price"> <?php echo e($product->old_price); ?> </span>
                                                </div>
                                                <div class="product-action-1 show">
                                                    <?php if($witems->contains($product->id)): ?>
                                                    
                                                    <a aria-label="Remove from Wishlist" class="action-btn hover-up wishlisted"
                                                    href="#" wire:click.prevent="removeFromWishlist(<?php echo e($product->id); ?>)"><i class="fi-rs-heart"></i></a>
                                                    <?php else: ?>
                                                    <a aria-label="Add To Wishlist" class="action-btn hover-up"
                                                    href="#" wire:click.prevent="addToWishlist(<?php echo e($product->id); ?>,'<?php echo e($product->name); ?>',<?php echo e($product->regular_price); ?>)"><i class="fi-rs-heart"></i></a>
    <?php endif; ?>
                                                    <a aria-label="Add To Cart" class="action-btn hover-up"
                                                        href="#" wire:click.prevent="store(<?php echo e($product->id,); ?>,'<?php echo e($product->name); ?>',<?php echo e($product->regular_price); ?>)"><i class="fi-rs-shopping-bag-add"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                            </div>
                            <!--pagination-->
                            <div class="pagination-area mt-15 mb-sm-5 mb-lg-0">
                                <?php echo e($products->links()); ?>

                                
                            </div>
                        </div>
                       
                    </div>
                </div>
            </section>
        </main>
    
    </div><?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/exclusivedeals-component.blade.php ENDPATH**/ ?>