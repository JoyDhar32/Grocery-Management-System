<div class="header-action-icon-2">
    <a href="<?php echo e(route('shop.wishlist')); ?>">
        <img class="svgInject" alt="WishList" src="<?php echo e(asset('assets/imgs/theme/icons/icon-heart.svg')); ?>">
        <?php if(Cart::instance('wishlist')->count() > 0): ?>
            <span class="pro-count blue"><?php echo e(Cart::instance('wishlist')->count()); ?></span>
        <?php endif; ?>
    </a>
</div>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/wish-list-icon-component.blade.php ENDPATH**/ ?>