<div>
    <style>
        nav svg{
            height:20px;
        }
    nav .hidden{
        display:block;
    }
    </style>
        <main class="main">
            <div class="page-header breadcrumb-wrap">
                <div class="container">
                    <div class="breadcrumb">
                        <a href="/" rel="nofollow">Home</a>
                        <span></span> Shop
                    </div>
                </div>
            </div>
            <section class="mt-50 mb-50">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9">
                            <div class="shop-product-fillter">
                                <div class="totall-product">
                                    <p> We found <strong class="text-brand"><?php echo e($products->total()); ?></strong> items for you!</p>
                                </div>
                                
                            </div>
    
                            <div class="row product-grid-3">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4 col-md-4 col-6 col-sm-6">
                                        <div class="product-cart-wrap mb-30">
                                            <div class="product-img-action-wrap">
                                                <div class="product-img product-img-zoom">
                                                    <a href="<?php echo e(route('product.details', ['slug' => $product->slug])); ?>">
                                                        <img class="default-img" src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($product->images); ?>-1.jpg" alt="Product Image">
                                                        <img class="hover-img" src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($product->images); ?>-2.jpg" alt="Product Image">
                                                    </a>
                                                </div>
                                        
                                            </div>
                                            <div class="product-content-wrap">
                                                
                                                <h2><a
                                                        href="<?php echo e(route('product.details', ['slug' => $product->slug])); ?>"><?php echo e($product->name); ?></a>
                                                </h2>
                                                <div class="rating-result" title="90%">
                                                    <span>
                                                        <span>90%</span>
                                                    </span>
                                                </div>
                                                <div class="product-price">
                                                    <span><?php echo e($product->regular_price); ?>$ </span>
                                                    <span class="old-price"> <?php echo e($product->old_price); ?>$ </span>
                                                </div>
                                                <div class="product-action-1 show">
                                                    <a aria-label="Add To Cart" class="action-btn hover-up"
                                                        href="#" wire:click.prevent="store(<?php echo e($product->id,); ?>,'<?php echo e($product->name); ?>',<?php echo e($product->regular_price); ?>)"><i class="fi-rs-shopping-bag-add"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                            </div>
                            <!--pagination-->
                            <div class="pagination-area mt-15 mb-sm-5 mb-lg-0">
                                <?php echo e($products->links()); ?>

                                
                            </div>
                        </div>
                        <div class="col-lg-3 primary-sidebar sticky-sidebar">
                            <div class="row">
                                <div class="col-lg-12 col-mg-6"></div>
                                <div class="col-lg-12 col-mg-6"></div>
                            </div>
                            <div class="widget-category mb-30">
                                <h5 class="section-title style-1 mb-30 wow fadeIn animated">Category</h5>
                                <ul class="categories">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('product.category',['slug'=>$category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <!-- Fillter By Price -->
                        
                            <!-- Product sidebar Widget -->
                            <div class="sidebar-widget product-sidebar  mb-30 p-30 bg-grey border-radius-10">
                                <div class="widget-header position-relative mb-20 pb-10">
                                    <h5 class="widget-title mb-10">New products</h5>
                                    <div class="bt-1 border-color-1"></div>
                                </div>
                                <?php $__currentLoopData = $rproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-post clearfix">
                                    <div class="image">
                                        <img class="default-img" src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($rproduct->images); ?>-1.jpg" alt="Product Image">
                                    </div>
                                    <div class="content pt-10">
                                        <h5><a href="<?php echo e(route('product.details',['slug'=>$rproduct->slug])); ?>"><?php echo e($rproduct->name); ?></a></h5>
                                        <p class="price mb-0 mt-5"><?php echo e($rproduct->regular_price); ?></p>
                                        <div class="product-rate">
                                            <div class="product-rating" style="width:90%"></div>
                                        </div>
                                    </div>
                                </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                            </div>
                    
                        </div>
                    </div>
                </div>
            </section>
        </main>
    
    </div>
    <?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/search-component.blade.php ENDPATH**/ ?>