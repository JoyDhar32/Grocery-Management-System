<div>
<style>
    nav svg{
        height:20px;
    }
nav .hidden{
    display:block;
}
.wishlisted{
    background: #F15412 !important;
    border: 1px solid transparent !important;
}
.wishlisted i{
    color: #fff !important;
}
</style>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="/" rel="nofollow">Home</a>
                    <span></span> Shop
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="shop-product-fillter">
                            <div class="totall-product">
                                <p> We found <strong class="text-brand"><?php echo e($products->total()); ?></strong> items for you!</p>
                            </div>
                            <div class="sort-by-product-area">
                                <div class="sort-by-cover mr-10">
                                    <div class="sort-by-product-wrap">
                                        <div class="sort-by">
                                            <span><i class="fi-rs-apps"></i>Show:</span>
                                        </div>
                                        <div class="sort-by-dropdown-wrap">
                                            <span> <?php echo e($pageSize); ?> <i class="fi-rs-angle-small-down"></i></span>
                                        </div>
                                    </div>
                                    <div class="sort-by-dropdown">
                                        <ul>
                                            <li><a class="<?php echo e($pageSize==12? 'active': ''); ?>" href="#" wire:click.prevent="changePageSize(12)">12</a></li>
                                            <li><a class="<?php echo e($pageSize==15? 'active': ''); ?>" href="#" wire:click.prevent="changePageSize(15)">15</a></li>
                                            <li><a class="<?php echo e($pageSize==25? 'active': ''); ?>" href="#"wire:click.prevent="changePageSize(25)">25</a></li>
                                            <li><a class="<?php echo e($pageSize==30? 'active': ''); ?>" href="#"wire:click.prevent="changePageSize(30)">30</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="sort-by-cover">
                                    <div class="sort-by-product-wrap">
                                        <div class="sort-by">
                                            <span><i class="fi-rs-apps-sort"></i>Sort by:</span>
                                        </div>
                                        <div class="sort-by-dropdown-wrap">
                                            <span> Default Sorting <i class="fi-rs-angle-small-down"></i></span>
                                        </div>
                                    </div>
                                    <div class="sort-by-dropdown">
                                        <ul>
                                            <li><a class="<?php echo e($orderBy=='Default Sorting'?'active': ''); ?>" href="#"  wire:click.prevent="changeOrderBy('Default Sorting')">Default Sorting</a></li>
                                            <li><a class="<?php echo e($orderBy=='Latest'?'active': ''); ?>" href="#" wire:click.prevent="changeOrderBy('Latest')">Latest</a></li>
                                            <li><a class="<?php echo e($orderBy=='Price: Low to High'?'active': ''); ?>" href="#" wire:click.prevent="changeOrderBy('Price: Low to High')">Price: Low to High</a></li>
                                            <li><a class="<?php echo e($orderBy=='Price: High to Low'?'active': ''); ?>" href="#" wire:click.prevent="changeOrderBy('Price: High to Low')">Price: High to Low</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row product-grid-3">
                            <?php
                                $witems = Cart::instance('wishlist')->content()->pluck('id');
                            ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-4 col-6 col-sm-6">
                                    <div class="product-cart-wrap mb-30">
                                        <div class="product-img-action-wrap">
                                            <div class="product-img product-img-zoom">
                                                <a href="<?php echo e(route('product.details', ['slug' => $product->slug])); ?>">
                                                    <img class="default-img" src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($product->images); ?>-1.jpg" alt="<?php echo e($product->name); ?>">
                                                    <img class="hover-img" src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($product->images); ?>-2.jpg" alt="<?php echo e($product->name); ?>">
                                                </a>
                                            </div>
                                       
                                            <div class="product-badges product-badges-position product-badges-mrg">
                                                <span class="hot" style="background:green">InStock</span>
                                            </div>
                                        </div>
                                        <div class="product-content-wrap">
                                          
                                            <h2>
                                                <a
                                                    href="<?php echo e(route('product.details', ['slug' => $product->slug])); ?>"><?php echo e($product->name); ?></a>
                                            </h2>
                                            <div class="product-price">
                                                <span><?php echo e($product->regular_price); ?>$ </span>
                                                <span class="old-price"> <?php echo e($product->old_price); ?> </span>
                                            </div>
                                            <div class="product-action-1 show">
                                                <?php if($witems->contains($product->id)): ?>
                                                
                                                <a aria-label="Remove from Wishlist" class="action-btn hover-up wishlisted"
                                                href="#" wire:click.prevent="removeFromWishlist(<?php echo e($product->id); ?>)"><i class="fi-rs-heart"></i></a>
                                                <?php else: ?>
                                                <a aria-label="Add To Wishlist" class="action-btn hover-up"
                                                href="#" wire:click.prevent="addToWishlist(<?php echo e($product->id); ?>,'<?php echo e($product->name); ?>',<?php echo e($product->regular_price); ?>)"><i class="fi-rs-heart"></i></a>
<?php endif; ?>
                                                <a aria-label="Add To Cart" class="action-btn hover-up"
                                                    href="#" wire:click.prevent="store(<?php echo e($product->id,); ?>,'<?php echo e($product->name); ?>',<?php echo e($product->regular_price); ?>)"><i class="fi-rs-shopping-bag-add"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <!--pagination-->
                        <div class="pagination-area mt-15 mb-sm-5 mb-lg-0">
                            <?php echo e($products->links()); ?>

                            
                        </div>
                    </div>
                    <div class="col-lg-3 primary-sidebar sticky-sidebar">
                        <div class="row">
                            <div class="col-lg-12 col-mg-6"></div>
                            <div class="col-lg-12 col-mg-6"></div>
                        </div>
                        <div class="widget-category mb-30">
                            <h5 class="section-title style-1 mb-30 wow fadeIn animated">Category</h5>
                            <ul class="categories">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('product.category',['slug'=>$category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Fillter By Price -->
                        <div class="sidebar-widget price_range range mb-30">
                            <div class="widget-header position-relative mb-20 pb-10">
                                <h5 class="widget-title mb-10">Filter by price</h5>
                                <div class="bt-1 border-color-1"></div>
                            </div>
                            <div class="price-filter">
                                <div class="price-filter-inner">
                                    <div id="slider-range"wire:ignore></div>
                                    <div class="price_slider_amount">
                                        <div class="label-input">
                                            <span>Range:</span> <span class="text-info">$<?php echo e($min_value); ?></span> - <span class="text-info">$<?php echo e($max_value); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                     
                        </div>
                        <!-- Product sidebar Widget -->
                        <div class="sidebar-widget product-sidebar  mb-30 p-30 bg-grey border-radius-10">
                            <div class="widget-header position-relative mb-20 pb-10">
                                <h5 class="widget-title mb-10">You may Like</h5>
                                
                                <div class="bt-1 border-color-1"></div>
                            </div>
                            <?php $__currentLoopData = $best_sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $best_sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-post clearfix">
                                <div class="image">
                                    <img class="default-img" src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($best_sell->images); ?>-1.jpg" alt="Product Image">
                                </div>
                                <div class="content pt-10">
                                    <h5><a href="<?php echo e(route('product.details',['slug'=>$best_sell->slug])); ?>"><?php echo e($best_sell->name); ?></a></h5>
                                    <p class="price mb-0 mt-5"><?php echo e($best_sell->regular_price); ?></p>
                                    <div class="product-rate">
                                        <div class="product-rating" style="width:90%"></div>
                                    </div>
                                </div>
                            </div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>
    </main>

</div>
<?php $__env->startPush('scripts'); ?>
<script>
var sliderrange = $('#slider-range');
    var amountprice = $('#amount');
    $(function() {
        sliderrange.slider({
            range: true,
            min: 0,
            max: 1000,
            values: [0, 1000],
            slide: function(event, ui) {
                //amountprice.val("$" + ui.values[0] + " - $" + ui.values[1]);
                window.livewire.find('<?php echo e($_instance->id); ?>').set('min_value',ui.values[0]);
                window.livewire.find('<?php echo e($_instance->id); ?>').set('max_value',ui.values[1]);
            }
        });
        
    }); 
</script>
<?php $__env->stopPush(); ?><?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/shop-component.blade.php ENDPATH**/ ?>