<div>
    <style>
        nav svg {
            height: 20px;
        }

        nav .hidden {
            display: block;
        }
    </style>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('home.index')); ?>" rel="nofollow">Home</a>
                    <span></span> Add New Category
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-6">
                                    Add Categories
                                </div>

                                <div class="col-md-6">
                                    <a class="btn btn-success float-end" href="<?php echo e(route('admin.categories')); ?>"> All
                                        Categories</a>
                                </div>
                            </div>
                        </div>
                        <div class="container offset-md-3">
                        <div class="card-body">
                            <?php if(Session::has('mesage')): ?>
                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                            <?php endif; ?>
                            <form wire.submit.prevent="storeCategory">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-4 mt-3">
                                    <label for="name" class="form-label">Product Name</label>
                                    <input type="text" class="form-control" placeholder="enter product name"
                                        name="name" wire:model="name" wire:keyup="generateSlug">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4 mt-3">
                                    <label for="name" class="form-label">Product Slug</label>
                                    <input type="text" class="form-control" placeholder="enter product slug"
                                        name="slug" wire:model="slug">
                                        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4 mt-3">
                                <button type="submit" class="btn btn-primary float-end">Add Category</button>
                                </div>
                            </form>
                        </div></div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <div>
    </div>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/admin/admin-add-category-component.blade.php ENDPATH**/ ?>