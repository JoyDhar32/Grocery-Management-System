<div>
   
    <h1>Admin Dashboard</h1>



</div>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/admin/admin-dashboard-component.blade.php ENDPATH**/ ?>