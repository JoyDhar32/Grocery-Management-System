<style>
    .hotline p i{
        color:#16542E;
    }
    .text-container{
        max-width: 260px; /* Adjust the max width as per your requirement */
    overflow: hidden;
    white-space: nowrap;
    }
    .truncate {
    text-overflow: ellipsis;
}
</style>
<div>
    <div class="header-bottom header-bottom-bg-color sticky-bar">
        <div class="container">
            <div class="header-wrap header-space-between position-relative">
                <div class="logo logo-width-1 d-block d-lg-none">
                    <a href="<?php echo e(route('home.index')); ?>"><img src="<?php echo e(asset('assets/imgs/logo/logo.png')); ?>" alt="logo"></a>
                </div>
                <div class="header-nav d-none d-lg-flex">
                    <div class="main-categori-wrap d-none d-lg-block">
                        <a class="categori-button-active" href="#">
                            <span class="fi-rs-apps"></span> Browse Categories & Products
                        </a>
                        <div class="categori-dropdown-wrap categori-dropdown-active-large">
                            <ul>
                                <li class="has-children">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('product.category',[$category->slug])); ?>"><i class="surfsidemedia-font-dress"></i><?php echo e($category->name); ?></a>
                                        
                                    <div class="dropdown-menu">
                                        <ul class="mega-menu d-lg-flex">
                                            <li class="mega-menu-col col-md-9">
                                                <ul class="d-lg-flex">
                                                    <li class="mega-menu-col col-lg-6">
                                                        <ul>
                                                          
                                                            <li><span class="submenu-title">Trending & Best Selling</span>
                                                            </li>
                                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                            <li class="text-container"><a class="dropdown-item nav-link nav_item truncate "
                                                                    href="<?php echo e(route('product.details',['slug'=>$product->slug])); ?>"><?php echo e($product->name); ?></a></li>
                                                                   
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </li>
                                                    <li class="mega-menu-col col-lg-6">
                                                        <ul>
                                                          
                                                            <li><span class="submenu-title">Popular & Featured</span>
                                                            </li>
                                                        <?php $__currentLoopData = $products1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                            <li  class="text-container"><a class="dropdown-item nav-link nav_item truncate"
                                                                    href="<?php echo e(route('product.details',['slug'=>$product->slug])); ?>"><?php echo e($product->name); ?></a></li>
                                                                   
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="mega-menu-col col-lg-3">
                                                <div class="header-banner2">
                                                    <img src="<?php echo e(asset('assets/imgs/shop/FRIED-038-2.jpg')); ?>"
                                                        alt="menu_banner1">
                                                </div>
                                                <div class="header-banner2">
                                                    <img src="<?php echo e(asset('assets/imgs/shop/DIP-012-2.jpg')); ?>"
                                                        alt="menu_banner2">
                                                 
                                                </div>
                                                <div class="header-banner2">
                                                    <img src="<?php echo e(asset('assets/imgs/shop/LAS-017-2.jpg')); ?>"
                                                        alt="menu_banner1">
                                                
                                                </div>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </li>
                            </ul>
                            
                        </div>
                    </div>
                    <div class="main-menu main-menu-padding-1 main-menu-lh-2 d-none d-lg-block" >
                        <nav>
                            <ul>
                                <li><a class="<?php echo e(Request::url() == route('home.index') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('home.index')); ?>">Home </a></li>
                                <li><a class="<?php echo e(Request::url() == route('home.about') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('home.about')); ?>">About Us</a></li>
                                <li><a class="<?php echo e(Request::url() == route('shop') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('shop')); ?>">Shop</a></li>
                                
                                <li><a class="<?php echo e(Request::url() == route('home.contact') ? 'active' : ''); ?>"
                                        href="<?php echo e(route('home.contact')); ?>">Contact</a></li>

                                        <?php if(auth()->guard()->check()): ?>
                                <li><a href="#">My Account<i class="fi-rs-angle-down"></i></a>
                                 
                                        <?php if(Auth::user()->utype == 'ADM'): ?>
                               
                                            <ul class="sub-menu">
                                            
                                                <li><a href="<?php echo e(route('admin.products')); ?>">Products</a></li>
                                                <li><a href="<?php echo e(route('admin.categories')); ?>">Categories</a></li>
                                                <li><a href="<?php echo e(route('admin.allorders')); ?>">All-Orders</a></li>
                                                <li><a href="<?php echo e(route('admin.orders_history')); ?>">Order-History</a></li>
                                                <li><a href="<?php echo e(route('admin.users')); ?>">Users</a></li>
                                                <li><a href="<?php echo e(route('admin.subscriber')); ?>">Subscriber</a></li>
                                                <li><a href="<?php echo e(route('admin.messages')); ?>">Messages</a></li>
                                                <li>
                                                <li>
                                                    <form action="<?php echo e(route('logout')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="submit" class="text-start" style="color:red;background:transparent;font-weight:bold;border:none;font-size:18px;margin-top:0" value="Logout"
                                                            onclick="event.preventDefault(; this.closest('form').submit();)"/>
                                                    </form>
                                                </li>
                                            </ul>
                                        <?php else: ?>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo e(route('user.myorders')); ?>">My Orders</a></li>
                                      
                                                <li>
                                                    <form action="<?php echo e(route('logout')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="submit" class="text-start" style="color:red;background:transparent;font-weight:bold;border:none;font-size:18px;margin-top:0" value="Logout"
                                                            onclick="event.preventDefault(; this.closest('form').submit();)"/>
                                                    </form>
                                                </li>
                                            </ul>
                                        <?php endif; ?>
                                    
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                </div>
                
                <div class="hotline d-none d-lg-block">
                    <p><i class="fa fa-shopping-cart" style="font-size:24px"></i><span><a href="<?php echo e(route('exclusive.deals')); ?>"> Exclusive Deals </a></p>
                </div>
           
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/show-category-component.blade.php ENDPATH**/ ?>