<div>
    <style>
        nav svg {
            height: 20px;
        }

        nav .hidden {
            display: block;
        }

        td,
        th {
            text-align: center;
        }

        .btn_approve:hover {
            font-weight: bold;
            cursor: pointer;
        }

        .btn_reject:hover {
            font-weight: bold;
            cursor: pointer;
        }
    </style>

    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('home.index')); ?>" rel="nofollow">Home</a>
                    <span></span> Orders
                </div>
            </div>
        </div>
        <section class="mt-2 mb-2">
            <div class="container">
                <?php if($orders->count()>0): ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php if(Session()->has('message')): ?>
                            <div class="alert alert-success"> <?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>

                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-6">
                                    All Orders
                                </div>

                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>FullName</th>
                                        <th>UserName</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Products</th>
                                        <th>Quantity</th>
                                        <th>Total</th>
                                        <th>Address</th>
                                        <th>City</th>
                                        <th>Zip</th>
                                        <th>Payment</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i=($orders->currentPage()-1)*$orders->perPage();  ?>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            <td><?php echo e($order->fname); ?> <?php echo e($order->lname); ?></td>
                                            <td><?php echo e($order->username); ?></td>
                                            <td><?php echo e($order->email); ?></td>
                                            <td><?php echo e($order->phone); ?></td>
                                            <td><?php echo e($order->products); ?></td>
                                            <td><?php echo e($order->qty); ?></td>
                                            <td><?php echo e($order->total); ?>$</td>
                                            <td><?php echo e($order->address); ?></td>
                                            <td><?php echo e($order->city); ?></td>
                                            <td><?php echo e($order->zipcode); ?></td>
                                            <td><?php echo e($order->payment_option); ?></td>
                                            <td>
                                                <div class="row">
                                                    
                                                    <button type="button"
                                                        class="btn btn-danger btn-sm col-md-5 mr-2 btn_approve"
                                                        style="background:transparent;border:none;"
                                                        onclick="confirm('Are you sure to approve product???')|| event.stopImmediatePropagation()"
                                                        wire:click.prevent="approve(<?php echo e($order->id); ?>)"><i
                                                            class="fa fa-check btn_approve"
                                                            style="font-size:20px;color:green; "></i></button>
                                                    <button type="button"
                                                        class="btn btn-danger btn-sm col-md-5 btn_reject"
                                                        style="background:transparent;border:none;"
                                                        onclick="confirm('Are you sure to delete product???')|| event.stopImmediatePropagation()"
                                                        wire:click.prevent="delete(<?php echo e($order->id); ?>)"><i
                                                            class="fa fa-trash btn_reject"
                                                            style="font-size:20px;color:red; "></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($orders->links()); ?>

                        </div>
                    </div>
                </div>
                <?php else: ?>
                <p class="alert alert-warning mt-50 mb-50"style="font-weight:bold;">No Pending Orders</p>
                <?php endif; ?>

            </div>
        </section>
    </main>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/admin/manage-order-component.blade.php ENDPATH**/ ?>