
<div>
    <style>
        nav svg {
            height: 20px;
        }

        nav .hidden {
            display: block;
        }
        .btn_reject:hover {
            font-weight: bold;
            cursor: pointer;
        }
    </style>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('home.index')); ?>" rel="nofollow">Home</a>
                    <span></span> subscribers
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <?php if(Session()->has('message')): ?>
                            <div class="alert alert-success"> <?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>
                        
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-6">
                                    Subscribers
                                </div>
                          
                                
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>User Email</th>
                                        <th>Role</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i=($subscribers->currentPage()-1)*$subscribers->perPage();  ?>
                                    <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            <td><?php echo e($subscriber->email); ?></td>
                                            <td>Subscriber</td>
                                            <td>
                                              
                                                
                                          
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($subscribers->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        
    </main>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/admin/view-subscriber-component.blade.php ENDPATH**/ ?>