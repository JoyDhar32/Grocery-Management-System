<div>
    <style>
        nav svg {
            height: 20px;
        }

        nav .hidden {
            display: block;
        }

        td,
        th {
            text-align: center;
        }
    </style>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('home.index')); ?>" rel="nofollow">Home</a>
                    <span></span> Add New Category
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <?php if(Session()->has('message')): ?>
                            <div class="alert alert-success"> <?php echo e(Session::get('message')); ?></div>
                        <?php endif; ?>

                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-6">
                                    All Products
                                </div>
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-info float-end" data-bs-toggle="modal"
                                        data-bs-target="#addProduct">
                                        Add Product
                                    </button>

                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>SKU</th>
                                        <th>Selling Price</th>
                                        <th>Old Price</th>
                                        <th>Stock</th>
                                        <th>Featured</th>
                                        <th>Popular</th>
                                        <th>Best Sell</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="image product-thumbnail"><img src="<?php echo e(asset('assets/imgs/shop')); ?>/<?php echo e($product->images); ?>-1.jpg" alt="#"></td>
                                            <td><?php echo e($product->name); ?></td>
                                            <td><?php echo e($product->slug); ?></td>
                                            <td><?php echo e($product->SKU); ?></td>
                                            <td><?php echo e($product->regular_price); ?>$</td>
                                            <td><?php echo e($product->old_price); ?>$</td>
                                            <td><?php echo e($product->stock_status); ?></td>
                                            <td><?php echo e($product->featured); ?></td>
                                            <td><?php echo e($product->popular); ?></td>
                                            <td><?php echo e($product->best_sell); ?></td>
                                            <td>
                                                
                                                <button type="button" class="btn btn-danger btn-sm" wire:click.prevent="delete(<?php echo e($product->id); ?>)">X</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($products->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php echo $__env->make('livewire.admin.create-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        

    </main>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/admin/admin-product-component.blade.php ENDPATH**/ ?>