<div>
    <div class="header-action-icon-2">
        <a class="mini-cart-icon" href="<?php echo e(route('shop.cart')); ?>">
            <img alt="Cart" src="<?php echo e(asset('assets/imgs/theme/icons/icon-cart.svg')); ?>">
            <?php if(Cart::instance('cart')->count()>0): ?>
            <span class="pro-count blue"><?php echo e(Cart::instance('cart')->count()); ?></span>
            <?php endif; ?>
        </a>
        <div class="cart-dropdown-wrap cart-dropdown-hm2">
            <ul>
                <?php $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="shopping-cart-img">
                        <a href="<?php echo e(route('product.details', ['slug' => $item->model->slug])); ?>"><img alt="<?php echo e($item->model->name); ?>"
                                src="<?php echo e(asset('assets/imgs/shop/')); ?>/<?php echo e($item->model->images); ?>-1.jpg"></a>
                    </div>
                    <div class="shopping-cart-title">
                        <h4><a href="<?php echo e(route('product.details', ['slug' => $item->model->slug])); ?>"><?php echo e(substr($item->model->name,0,20)); ?>...</a></h4>
                        <h4><span><?php echo e($item->qty); ?> × </span>$<?php echo e($item->model->regular_price); ?></h4>
                    </div>
                    
                </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </ul>
        <?php if(Cart::instance('cart')->count()>0): ?>

            <div class="shopping-cart-footer">
                <div class="shopping-cart-total">
                    <h4>Total <span>$<?php echo e(Cart::instance('cart')->total()); ?></span></h4>
                </div>
                <div class="shopping-cart-button">
                    <a href="<?php echo e(route('shop.cart')); ?>" class="outline">View cart</a>
                    <a href="<?php echo e(route('shop.checkout')); ?>">Checkout</a>
                </div>
            </div>
        </div>
        <?php else: ?>
        <p class="alert alert-warning"style="font-weight:bold;">No Item in Cart <a href="<?php echo e(route('shop')); ?>" style="margin-left:5px;font-weight:bold;">Shop</a></p>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/cart-icon-component.blade.php ENDPATH**/ ?>