<div>
    <style>
        nav svg {
            height: 20px;
        }

        nav .hidden {
            display: block;
        }

        .wishlisted {
            background: #F15412 !important;
            border: 1px solid transparent !important;
        }

        .wishlisted i {
            color: #fff !important;
        }

        .product-cart-wrap .product-action-1 button:after,
        .product-cart-wrap .product-action-1 a.action-btn:after {
            left: -32%;
        }
    </style>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="/" rel="nofollow">Home</a>
                    <span></span> Wishlist
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <?php if(Cart::instance('wishlist')->count()>0): ?>

                <div class="row product-grid-4">
                    <?php $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-3 col-6 col-sm-6">
                            <div class="product-cart-wrap mb-30">
                                <div class="product-img-action-wrap">
                                    <div class="product-img product-img-zoom">
                                        <a href="<?php echo e(route('product.details', ['slug' => $item->model->slug])); ?>">
                                            <img class="default-img"
                                                src="<?php echo e(asset('assets/imgs/shop/')); ?>/<?php echo e($item->model->images); ?>-1.jpg"
                                                alt="<?php echo e($item->model->name); ?>">
                                            <img class="hover-img"
                                                src="<?php echo e(asset('assets/imgs/shop/')); ?>/<?php echo e($item->model->images); ?>-2.jpg"
                                                alt="<?php echo e($item->model->name); ?>">
                                        </a>
                                    </div>
                               
                                    <div class="product-badges product-badges-position product-badges-mrg">
                                        <span class="hot">Wishlist</span>
                                    </div>
                                </div>
                                <div class="product-content-wrap">
                                    
                                    <h2><a
                                            href="<?php echo e(route('product.details', ['slug' => $item->model->slug])); ?>"><?php echo e($item->model->name); ?></a>
                                    </h2>
                                    <div class="rating-result" title="90%">
                                        <span>
                                            <span>90%</span>
                                        </span>
                                    </div>
                                    <div class="product-price">
                                        <span><?php echo e($item->model->regular_price); ?>$ </span>
                                        <span class="old-price"> <?php echo e($item->model->old_price); ?>$php a </span>
                                    </div>
                                    <div class="product-action-1 show">

                                        <a aria-label="Remove from Wishlist" class="action-btn hover-up wishlisted"
                                            href="#"
                                            wire:click.prevent="removeFromWishlist(<?php echo e($item->model->id); ?>)"><i
                                                class="fi-rs-heart"></i></a>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <p class="alert alert-warning"style="font-weight:bold;">No Item in Wishlist</p>
                <?php endif; ?>
            </div>
        </section>
</div>
<?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/livewire/wishlist-component.blade.php ENDPATH**/ ?>