<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Error Page</title>
</head>
<body>
   This page does not exits 
   <a href="<?php echo e(route('home.index')); ?>"> Back To Home</a>
</body>
</html><?php /**PATH H:\xampp\htdocs\Laravel\grocery\resources\views/errors/404.blade.php ENDPATH**/ ?>